import json
from pathlib import Path


class DomainMemory:

    FILE = Path("memory/domain_patterns.json")

    def __init__(self):
        self.FILE.parent.mkdir(exist_ok=True)

        if self.FILE.exists():
            self.patterns = json.loads(self.FILE.read_text())
        else:
            self.patterns = []

    def record(self, pattern):

        self.patterns.append(pattern)

        self.FILE.write_text(
            json.dumps(self.patterns, indent=2)
        )

    def get_patterns(self):
        return self.patterns