package com.preschoolmanagement.child.application.mapper;

import com.preschoolmanagement.child.domain.model.GeoLocation;



@Mapper
public interface AuthorizedPickupMapper {

    AuthorizedPickup toDomain(AuthorizedPickupRequest request);

    AuthorizedPickupResponse toResponse(AuthorizedPickup authorizedPickup);
}
