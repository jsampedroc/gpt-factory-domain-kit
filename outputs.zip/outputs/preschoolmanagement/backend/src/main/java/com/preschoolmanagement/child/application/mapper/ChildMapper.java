package com.preschoolmanagement.child.application.mapper;

import com.preschoolmanagement.child.domain.model.Allergy;
import com.preschoolmanagement.child.domain.model.AuthorizedPickup;
import com.preschoolmanagement.child.domain.model.Immunization;
import java.util.List;



@Mapper
public interface ChildMapper {

    Child toDomain(ChildRequest request);

    ChildResponse toResponse(Child child);
}
