package com.preschoolmanagement.child.application.usecase;

import com.preschoolmanagement.child.domain.model.Allergy;
import com.preschoolmanagement.child.domain.model.AuthorizedPickup;
import com.preschoolmanagement.child.domain.model.Immunization;
import java.util.List;



public class ChildUseCase {

    private final ChildRepository repository;

    public ChildUseCase(ChildRepository repository) {
        this.repository = repository;
    }

}
