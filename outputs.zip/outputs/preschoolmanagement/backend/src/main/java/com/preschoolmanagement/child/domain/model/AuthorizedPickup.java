package com.preschoolmanagement.child.domain.model;

import com.preschoolmanagement.domain.valueobject.AuthorizedPickupId;
import com.preschoolmanagement.domain.valueobject.GeoLocation;

public record AuthorizedPickup(
        AuthorizedPickupId id,
        String firstName,
        String lastName,
        String contactNumber,
        GeoLocation relationToChild
) {}
