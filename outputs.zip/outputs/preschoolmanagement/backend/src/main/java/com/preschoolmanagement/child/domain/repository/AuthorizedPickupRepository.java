package com.preschoolmanagement.child.domain.repository;

import com.preschoolmanagement.child.domain.model.GeoLocation;



public interface AuthorizedPickupRepository extends JpaRepository<AuthorizedPickup, UUID> {

}
