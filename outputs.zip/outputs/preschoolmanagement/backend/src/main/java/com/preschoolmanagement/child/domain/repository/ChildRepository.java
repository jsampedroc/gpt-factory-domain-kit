package com.preschoolmanagement.child.domain.repository;

import com.preschoolmanagement.child.domain.model.Allergy;
import com.preschoolmanagement.child.domain.model.AuthorizedPickup;
import com.preschoolmanagement.child.domain.model.Immunization;
import java.util.List;



public interface ChildRepository extends JpaRepository<Child, UUID> {

}
