package com.preschoolmanagement.child.domain.service;

import com.preschoolmanagement.child.domain.model.GeoLocation;



public class AuthorizedPickupDomainService {

    private final AuthorizedPickupRepository repository;

    public AuthorizedPickupDomainService(AuthorizedPickupRepository repository) {
        this.repository = repository;
    }

}
