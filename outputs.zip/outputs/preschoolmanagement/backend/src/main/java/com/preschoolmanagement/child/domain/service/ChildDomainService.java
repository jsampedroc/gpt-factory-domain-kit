package com.preschoolmanagement.child.domain.service;

import com.preschoolmanagement.child.domain.model.Allergy;
import com.preschoolmanagement.child.domain.model.AuthorizedPickup;
import com.preschoolmanagement.child.domain.model.Immunization;
import java.util.List;



public class ChildDomainService {

    private final ChildRepository repository;

    public ChildDomainService(ChildRepository repository) {
        this.repository = repository;
    }

}
