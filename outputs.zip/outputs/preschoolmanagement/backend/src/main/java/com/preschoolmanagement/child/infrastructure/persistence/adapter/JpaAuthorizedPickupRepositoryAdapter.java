package com.preschoolmanagement.child.infrastructure.persistence.adapter;

import com.preschoolmanagement.child.domain.model.GeoLocation;




@Repository
public class JpaAuthorizedPickupRepositoryAdapter implements AuthorizedPickupRepository {

    private final SpringDataAuthorizedPickupRepository repo;

    public JpaAuthorizedPickupRepositoryAdapter(SpringDataAuthorizedPickupRepository repo) {
        this.repo = Objects.requireNonNull(repo);
    }

    @Override
    public AuthorizedPickup save(AuthorizedPickup authorizedPickup) {
        AuthorizedPickupJpaEntity entity = new AuthorizedPickupJpaEntity(
                authorizedPickup.id().value(),
                authorizedPickup.firstName(),
                authorizedPickup.lastName(),
                authorizedPickup.contactNumber(),
                authorizedPickup.relationToChild()
        );
        AuthorizedPickupJpaEntity saved = repo.save(entity);
        return new AuthorizedPickup(
                new AuthorizedPickupId(saved.getId()),
                saved.getFirstName(),
                saved.getLastName(),
                saved.getContactNumber(),
                saved.getRelationToChild()
        );
    }

    @Override
    public Optional<AuthorizedPickup> findById(AuthorizedPickupId id) {
        return repo.findById(id.value())
                .map(e -> new AuthorizedPickup(
                        new AuthorizedPickupId(e.getId()),
                        e.getFirstName(),
                        e.getLastName(),
                        e.getContactNumber(),
                        e.getRelationToChild()
                ));
    }
}
