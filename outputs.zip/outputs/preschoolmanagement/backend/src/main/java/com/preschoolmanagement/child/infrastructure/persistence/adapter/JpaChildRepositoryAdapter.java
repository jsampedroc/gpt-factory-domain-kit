package com.preschoolmanagement.child.infrastructure.persistence.adapter;

import com.preschoolmanagement.child.domain.model.Allergy;
import com.preschoolmanagement.child.domain.model.AuthorizedPickup;
import com.preschoolmanagement.child.domain.model.Immunization;
import java.util.List;




@Repository
public class JpaChildRepositoryAdapter implements ChildRepository {

    private final SpringDataChildRepository repo;

    public JpaChildRepositoryAdapter(SpringDataChildRepository repo) {
        this.repo = Objects.requireNonNull(repo);
    }

    @Override
    public Child save(Child child) {
        ChildJpaEntity entity = new ChildJpaEntity(
                child.id().value(),
                child.firstName(),
                child.lastName(),
                child.birthDate(),
                child.allergies(),
                child.immunizations(),
                child.authorizedPickups()
        );
        ChildJpaEntity saved = repo.save(entity);
        return new Child(
                new ChildId(saved.getId()),
                saved.getFirstName(),
                saved.getLastName(),
                saved.getBirthDate(),
                saved.getAllergies(),
                saved.getImmunizations(),
                saved.getAuthorizedPickups()
        );
    }

    @Override
    public Optional<Child> findById(ChildId id) {
        return repo.findById(id.value())
                .map(e -> new Child(
                        new ChildId(e.getId()),
                        e.getFirstName(),
                        e.getLastName(),
                        e.getBirthDate(),
                        e.getAllergies(),
                        e.getImmunizations(),
                        e.getAuthorizedPickups()
                ));
    }
}
