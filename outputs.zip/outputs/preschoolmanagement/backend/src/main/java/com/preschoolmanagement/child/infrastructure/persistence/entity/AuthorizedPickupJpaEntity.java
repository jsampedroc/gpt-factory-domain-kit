package com.preschoolmanagement.child.infrastructure.persistence.entity;

import com.preschoolmanagement.child.domain.model.GeoLocation;



@Entity
public class AuthorizedPickupJpaEntity {

    @Id
    private UUID id;

    private String firstName;
    private String lastName;
    private String contactNumber;
    private GeoLocation relationToChild;

}
