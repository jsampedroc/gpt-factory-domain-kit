package com.preschoolmanagement.child.infrastructure.persistence.entity;

import com.preschoolmanagement.child.domain.model.Allergy;
import com.preschoolmanagement.child.domain.model.AuthorizedPickup;
import com.preschoolmanagement.child.domain.model.Immunization;
import java.util.List;



@Entity
public class ChildJpaEntity {

    @Id
    private UUID id;

    private String firstName;
    private String lastName;
    private LocalDate birthDate;
    private List<Allergy> allergies;
    private List<Immunization> immunizations;
    private List<AuthorizedPickup> authorizedPickups;

}
