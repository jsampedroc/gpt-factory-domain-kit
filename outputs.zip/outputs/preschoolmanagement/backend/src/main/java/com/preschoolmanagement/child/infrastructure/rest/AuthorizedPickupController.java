package com.preschoolmanagement.child.infrastructure.rest;

import com.preschoolmanagement.child.domain.model.GeoLocation;



@RestController
@RequestMapping("/authorizedpickups")
public class AuthorizedPickupController {

}
