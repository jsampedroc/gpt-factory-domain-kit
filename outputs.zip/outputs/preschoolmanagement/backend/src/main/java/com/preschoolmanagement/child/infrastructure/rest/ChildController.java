package com.preschoolmanagement.child.infrastructure.rest;

import com.preschoolmanagement.child.domain.model.Allergy;
import com.preschoolmanagement.child.domain.model.AuthorizedPickup;
import com.preschoolmanagement.child.domain.model.Immunization;
import java.util.List;



@RestController
@RequestMapping("/childs")
public class ChildController {

}
