package com.preschoolmanagement.parent.application.mapper;

import com.preschoolmanagement.parent.domain.model.Allergy;
import com.preschoolmanagement.parent.domain.model.AuthorizedPickup;
import com.preschoolmanagement.parent.domain.model.Immunization;
import java.util.List;



@Mapper
public interface ChildMapper {

    Child toDomain(ChildRequest request);

    ChildResponse toResponse(Child child);
}
