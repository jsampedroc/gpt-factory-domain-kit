package com.preschoolmanagement.parent.application.mapper;

import com.preschoolmanagement.parent.domain.model.Address;
import com.preschoolmanagement.parent.domain.model.Child;
import java.util.List;



@Mapper
public interface ParentMapper {

    Parent toDomain(ParentRequest request);

    ParentResponse toResponse(Parent parent);
}
