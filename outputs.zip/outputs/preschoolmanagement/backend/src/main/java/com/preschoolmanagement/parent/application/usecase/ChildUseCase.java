package com.preschoolmanagement.parent.application.usecase;

import com.preschoolmanagement.parent.domain.model.Allergy;
import com.preschoolmanagement.parent.domain.model.AuthorizedPickup;
import com.preschoolmanagement.parent.domain.model.Immunization;
import java.util.List;



public class ChildUseCase {

    private final ChildRepository repository;

    public ChildUseCase(ChildRepository repository) {
        this.repository = repository;
    }

}
