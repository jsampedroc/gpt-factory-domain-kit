package com.preschoolmanagement.parent.application.usecase;

import com.preschoolmanagement.parent.domain.model.Address;
import com.preschoolmanagement.parent.domain.model.Child;
import java.util.List;



public class ParentUseCase {

    private final ParentRepository repository;

    public ParentUseCase(ParentRepository repository) {
        this.repository = repository;
    }

}
