package com.preschoolmanagement.parent.domain.model;

import com.preschoolmanagement.domain.model.AuthorizedPickup;
import com.preschoolmanagement.domain.valueobject.Allergy;
import com.preschoolmanagement.domain.valueobject.ChildId;
import com.preschoolmanagement.domain.valueobject.Immunization;
import java.time.LocalDate;
import java.util.List;

public record Child(
        ChildId id,
        String firstName,
        String lastName,
        LocalDate birthDate,
        List<Allergy> allergies,
        List<Immunization> immunizations,
        List<AuthorizedPickup> authorizedPickups
) {}
