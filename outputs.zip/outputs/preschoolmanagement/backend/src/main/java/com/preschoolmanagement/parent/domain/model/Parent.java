package com.preschoolmanagement.parent.domain.model;

import com.preschoolmanagement.domain.model.Child;
import com.preschoolmanagement.domain.valueobject.Address;
import com.preschoolmanagement.domain.valueobject.ParentId;
import java.util.List;

public record Parent(
        ParentId id,
        String firstName,
        String lastName,
        String contactNumber,
        Address address,
        List<Child> children
) {}
