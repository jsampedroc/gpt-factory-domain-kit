package com.preschoolmanagement.parent.domain.repository;

import com.preschoolmanagement.parent.domain.model.Allergy;
import com.preschoolmanagement.parent.domain.model.AuthorizedPickup;
import com.preschoolmanagement.parent.domain.model.Immunization;
import java.util.List;



public interface ChildRepository extends JpaRepository<Child, UUID> {

}
