package com.preschoolmanagement.parent.domain.repository;

import com.preschoolmanagement.parent.domain.model.Address;
import com.preschoolmanagement.parent.domain.model.Child;
import java.util.List;



public interface ParentRepository extends JpaRepository<Parent, UUID> {

}
