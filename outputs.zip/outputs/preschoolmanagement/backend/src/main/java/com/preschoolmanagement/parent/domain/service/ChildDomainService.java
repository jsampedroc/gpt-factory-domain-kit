package com.preschoolmanagement.parent.domain.service;

import com.preschoolmanagement.parent.domain.model.Allergy;
import com.preschoolmanagement.parent.domain.model.AuthorizedPickup;
import com.preschoolmanagement.parent.domain.model.Immunization;
import java.util.List;



public class ChildDomainService {

    private final ChildRepository repository;

    public ChildDomainService(ChildRepository repository) {
        this.repository = repository;
    }

}
