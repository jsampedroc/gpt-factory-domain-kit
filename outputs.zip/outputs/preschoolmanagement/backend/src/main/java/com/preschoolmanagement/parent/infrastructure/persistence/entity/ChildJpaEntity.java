package com.preschoolmanagement.parent.infrastructure.persistence.entity;

import com.preschoolmanagement.parent.domain.model.Allergy;
import com.preschoolmanagement.parent.domain.model.AuthorizedPickup;
import com.preschoolmanagement.parent.domain.model.Immunization;
import java.util.List;



@Entity
public class ChildJpaEntity {

    @Id
    private UUID id;

    private String firstName;
    private String lastName;
    private LocalDate birthDate;
    private List<Allergy> allergies;
    private List<Immunization> immunizations;
    private List<AuthorizedPickup> authorizedPickups;

}
