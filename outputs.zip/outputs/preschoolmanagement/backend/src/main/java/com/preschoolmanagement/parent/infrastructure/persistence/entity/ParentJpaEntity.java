package com.preschoolmanagement.parent.infrastructure.persistence.entity;

import com.preschoolmanagement.parent.domain.model.Address;
import com.preschoolmanagement.parent.domain.model.Child;
import java.util.List;



@Entity
public class ParentJpaEntity {

    @Id
    private UUID id;

    private String firstName;
    private String lastName;
    private String contactNumber;
    private Address address;
    private List<Child> children;

}
