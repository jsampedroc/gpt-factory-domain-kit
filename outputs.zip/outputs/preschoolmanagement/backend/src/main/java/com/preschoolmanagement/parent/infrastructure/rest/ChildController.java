package com.preschoolmanagement.parent.infrastructure.rest;

import com.preschoolmanagement.parent.domain.model.Allergy;
import com.preschoolmanagement.parent.domain.model.AuthorizedPickup;
import com.preschoolmanagement.parent.domain.model.Immunization;
import java.util.List;



@RestController
@RequestMapping("/childs")
public class ChildController {

}
