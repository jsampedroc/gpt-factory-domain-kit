package com.preschoolmanagement.parent.infrastructure.rest;

import com.preschoolmanagement.parent.domain.model.Address;
import com.preschoolmanagement.parent.domain.model.Child;
import java.util.List;



@RestController
@RequestMapping("/parents")
public class ParentController {

}
